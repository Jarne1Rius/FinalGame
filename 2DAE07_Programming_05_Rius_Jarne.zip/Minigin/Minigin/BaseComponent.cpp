#include "MiniginPCH.h"
#include "BaseComponent.h"

Rius::BaseComponent::BaseComponent()
	:m_pGameObject(nullptr)
{
}
