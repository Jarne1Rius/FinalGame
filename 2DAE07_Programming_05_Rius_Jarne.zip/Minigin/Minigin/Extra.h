#pragma once
enum Tag
{
	Player,
	Ground,
	Interactions,
	Static
};

enum PositionUI
{
	Center,
	LeftTop,
	RightTop,
	LeftBottom,
	RightBottom
};
